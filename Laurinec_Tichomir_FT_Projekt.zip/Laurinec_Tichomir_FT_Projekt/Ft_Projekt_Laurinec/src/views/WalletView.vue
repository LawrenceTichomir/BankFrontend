<script lang="ts">
import {defineComponent} from 'vue'
import CardComponent from "@/components/CardComponent.vue";
import TransactionsSmall from "@/components/TransactionsSmall.vue";

export default defineComponent({
  name: "WalletView",
  components: {TransactionsSmall, CardComponent}
})
</script>

<template>
  <CardComponent/>
  <TransactionsSmall/>
</template>

<style scoped>

</style>