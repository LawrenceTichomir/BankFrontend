<script lang="ts">
import { defineComponent } from "vue";
import "@/assets/styles/help.css"
export default defineComponent({
  name: "HelpView",
});
</script>

<template>
  <div class="help-view">
    <header class="help-header">
      <h1>How can we help?</h1>
    </header>

    <div class="help-content">
      <div class="search-box">
        <h3>Search for the topics</h3>
        <div class="search-input">
          <input type="text" placeholder="Search"/>
          <button>Submit</button>
        </div>
      </div>

      <div class="cta-box">
        <h3>Still can't find what you looking for?</h3>
        <p>
          <strong>Call us:</strong> (60) 305-240-9671
        </p>
        <button>Chat with us</button>
      </div>
    </div>

    <section class="faq-section">
      <h3>Frequently Asked Questions</h3>
      <div class="faq-item">
        <p class="faq-question">
          <strong>What is Mini Finance Template?</strong>
        </p>
        <p class="faq-answer">
          Mini Finance Template includes total 6 HTML pages for your
          customizations. It is free of charge provided by Tooplate website.
        </p>
      </div>
      <div class="faq-item">
        <p class="faq-question">
          <strong>What is Free HTML Template?</strong>
        </p>
        <p class="faq-answer">
          Free HTML Template is a ready-made web page based on HTML CSS codes.
        </p>
      </div>
      <div class="faq-item">
        <p class="faq-question">
          <strong>What is the best code editor?</strong>
        </p>
        <p class="faq-answer">
          Popular code editors are Dreamweaver, Notepad++, Visual Studio Code,
          Rapid CSS, Sublime Text, and Atom to edit HTML CSS JS codes and put in
          your own web contents.
        </p>
      </div>
      <div class="faq-item">
        <p class="faq-question">
          <strong>Are all templates free to download?</strong>
        </p>
        <p class="faq-answer">
          Yes, all CSS templates are 100% free to download and use for your
          websites. You can also use them for learning HTML, CSS, and
          JavaScripts.
        </p>
      </div>
    </section>
  </div>
</template>

<style scoped>

</style>
