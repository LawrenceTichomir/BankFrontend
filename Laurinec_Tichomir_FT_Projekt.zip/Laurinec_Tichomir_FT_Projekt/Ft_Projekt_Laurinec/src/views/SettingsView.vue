<script lang="ts">
import { defineComponent } from "vue";
import "@/assets/styles/settings.css"
export default defineComponent({
  name: "SettingsView",
  data() {
    return {
      selectedTab: "Profile",
      profile: {
        name: "Tichomir Laurinec",
        email: "tichomir.laurinec@student.ukf.sk",
        picture: "/images/profile.jpg",
      },
      password: {
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      },
      notifications: {
        emailNotifications: false,
        smsNotifications: true,
      },
    };
  },
  methods: {
    updateProfile() {
      alert("Profile updated!");
    },
    resetProfile() {
      this.profile.name = "Tichomír Laurinec";
      this.profile.email = "tichomir.laurinec@student.ukf.sk";
      this.profile.picture = "/images/profile.jpg";
    },
    updatePassword() {
      if (this.password.newPassword !== this.password.confirmPassword) {
        alert("Passwords do not match!");
      } else {
        alert("Password updated!");
      }
    },
    updateNotifications() {
      alert("Notification preferences updated!");
    },
    changeTab(tab: string) {
      this.selectedTab = tab;
    },
  },
});
</script>

<template>
  <div class="settings-view">
    <h1 class="title">Settings</h1>

    <div class="tabs">
      <button v-for="tab in ['Profile', 'Password', 'Notification']" :key="tab" :class="{ active: selectedTab === tab }"
          @click="changeTab(tab)">
        {{ tab }}
      </button>
    </div>

    <div class="content">

      <div v-if="selectedTab === 'Profile'" class="profile-tab">
        <h2>User Profile</h2>
        <form class="profile-form">
          <input type="text" v-model="profile.name" placeholder="Name" class="form-input"/>
          <input type="email" v-model="profile.email" placeholder="Email" class="form-input"/>

          <div class="picture-section">
            <img :src="profile.picture" alt="Profile Picture" class="profile-picture"/>

            <div class="file-input">
              <label for="profilePicture">Choose File</label>
              <input type="file" id="profilePicture"/>
              <span>No file chosen</span>
            </div>

          </div>
          <div class="action-buttons">

            <button type="button" @click="resetProfile" class="reset-button">
              Reset
            </button>

            <button type="button" @click="updateProfile" class="update-button">
              Update
            </button>

          </div>
        </form>
      </div>

      <div v-if="selectedTab === 'Password'" class="password-tab">
        <h2>Change Password</h2>
        <form class="password-form">
          <input type="password" v-model="password.currentPassword" placeholder="Current Password" class="form-input"/>
          <input type="password" v-model="password.newPassword" placeholder="New Password" class="form-input"/>
          <input type="password" v-model="password.confirmPassword" placeholder="Confirm New Password" class="form-input"/>

          <button type="button" @click="updatePassword" class="update-button">
            Update Password
          </button>
        </form>
      </div>

      <div v-if="selectedTab === 'Notification'" class="notification-tab">
        <h2>Notification Preferences</h2>
        <form class="notification-form">

          <div class="notification-item">
            <input type="checkbox" v-model="notifications.emailNotifications" id="emailNotifications"/>
            <label for="emailNotifications">Email Notifications</label>
          </div>

          <div class="notification-item">
            <input type="checkbox" v-model="notifications.smsNotifications" id="smsNotifications"/>
            <label for="smsNotifications">SMS Notifications</label>
          </div>

          <button type="button" @click="updateNotifications" class="update-button">
            Update Preferences
          </button>

        </form>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>
