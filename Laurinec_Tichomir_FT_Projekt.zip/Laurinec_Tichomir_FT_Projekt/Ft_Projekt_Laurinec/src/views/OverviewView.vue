<script lang="ts">
import { defineComponent } from "vue";
import ExchangeRate from "@/components/ExchangeRate.vue";
import CardComponent from "@/components/CardComponent.vue";
import InfoCard from "@/components/InfoCard.vue";
import ActionPanel from "@/components/ActionPanel.vue";
import TransactionsSmall from "@/components/TransactionsSmall.vue";
import "@/assets/styles/overview.css"
export default defineComponent({
  name: "OverviewView",
  components: {
    ExchangeRate,
    CardComponent,
    InfoCard,
    ActionPanel,
    TransactionsSmall,
  },
});
</script>

<template>
  <div class="home-layout">
    <div class="content">
      <div class="main-content">
        <CardComponent/>
        <ExchangeRate/>
      </div>
      <div class="right-panel">
        <InfoCard class="info-card"/>
        <ActionPanel class="action-panel"/>
        <TransactionsSmall class="transactions-small"/>
      </div>
    </div>
    <main>
      <router-view/>
    </main>
  </div>
</template>

<style scoped>

</style>
