<script lang="ts">
import { defineComponent } from "vue";
import { useBalanceStore } from "@/stores/balance";
import CardInfo from "@/components/CardInfo.vue";
import "@/assets/styles/profile.css";

export default defineComponent({
  name: "ProfileView",
  components: { CardInfo },

  data() {
    return {
      transactionAmount: 0 as number,
      errorMessage: "" as string,
      balanceStore: useBalanceStore(),
    };
  },

  methods: {
    deposit() {
      if (this.transactionAmount > 0) {
        this.balanceStore.updateBalance(this.transactionAmount);
        this.errorMessage = "";
      } else {
        this.errorMessage = "Enter a valid deposit amount.";
      }
    },

    withdraw() {
      try {
        if (this.transactionAmount > 0) {
          this.balanceStore.withdrawBalance(this.transactionAmount);
          this.errorMessage = "";
        } else {
          this.errorMessage = "Enter a valid withdrawal amount.";
        }
      } catch (error) {
        const err = error as Error;
        console.error(err.message);
      }
    },
  },
});
</script>

<template>
  <div class="profile-view">
    <h1>User Profile</h1>

    <div class="profile-section">
      <img class="profile-picture" src="/images/profile.jpg" alt="Profile Picture" />
      <p>Tichomír Laurinec</p>
    </div>

    <div class="balance-section">
      <h2>Balance: €{{ balanceStore.balance.toFixed(2) }}</h2>
    </div>

    <div class="actions-section">
      <input type="number" v-model.number="transactionAmount" placeholder="Enter amount" />
      <button @click="deposit">Deposit</button>
      <button @click="withdraw">Withdraw</button>
    </div>

    <p v-if="errorMessage" class="error-message">{{ errorMessage }}</p>
  </div>

  <CardInfo />
</template>

<style scoped>
</style>
