import { createRouter, createWebHistory } from 'vue-router'
import HelpView from "@/views/HelpView.vue";
import ProfileView from "@/views/ProfileView.vue";
import SettingsView from "@/views/SettingsView.vue";
import WalletView from "@/views/WalletView.vue";
import OverviewView from "@/views/OverviewView.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'overview',
      component: OverviewView,
    },{
      path: '/wallet',
      name: 'wallet',
      component: WalletView,
    },
    {
      path: '/help',
      name: 'help',
      component: HelpView
    },{
      path: '/profile',
      name: 'profile',
      component: ProfileView
    }, {
      path: '/settings',
      name: 'settings',
      component: SettingsView
    },
  ],
})

export default router
