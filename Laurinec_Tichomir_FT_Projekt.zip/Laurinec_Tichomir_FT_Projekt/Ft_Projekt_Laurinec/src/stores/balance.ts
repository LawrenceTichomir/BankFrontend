import { defineStore } from "pinia";

export const useBalanceStore = defineStore("balance", {
    state: () => ({
        balance: parseFloat(localStorage.getItem("balance") || "0.23"),
    }),
    actions: {
        updateBalance(amount: number) {
            this.balance += amount;
            this.saveToLocalStorage();
        },
        withdrawBalance(amount: number) {
            if (amount <= this.balance) {
                this.balance -= amount;
                this.saveToLocalStorage();
            } else {
                throw new Error("Insufficient balance.");
            }
        },
        saveToLocalStorage() {
            localStorage.setItem("balance", this.balance.toString());
        },
    },
});
