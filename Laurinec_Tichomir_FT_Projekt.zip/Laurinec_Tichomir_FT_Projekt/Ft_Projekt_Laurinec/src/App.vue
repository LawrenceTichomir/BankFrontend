<script setup lang="ts">
import NavBar from "@/components/NavBar.vue";
import SideBar from "@/components/SideBar.vue";
</script>

<template>
  <NavBar/>
  <SideBar/>
  <main>
    <router-view/>
  </main>
</template>

<style scoped>
main {
  margin-left: 200px;
  margin-top: 60px;
  padding: 20px;
}
</style>
