<script lang="ts">
import { defineComponent } from "vue";
import "@/assets/styles/exchange.css"
export default defineComponent({
  name: "ExchangeRate",
  data() {
    return {
      exchangeRates: [
        { name: "EUR", flag: "/images/flags/eu.png", buy: 1.2, sell: 1.3 },
        { name: "USD", flag: "/images/flags/us.png", buy: 1.1, sell: 1.2 },
        { name: "GBP", flag: "/images/flags/uk.png", buy: 1.3, sell: 1.4 },
        { name: "AUD", flag: "/images/flags/au.png", buy: 0.9, sell: 1.0 },
        { name: "HUF", flag: "/images/flags/hu.png", buy: 300, sell: 310 },
      ],
    };
  },
});
</script>

<template>
  <div class="exchange-rates-table">
    <h2>Exchange Rates</h2>
    <table>
      <thead>
      <tr>
        <th>Flag</th>
        <th>Currency</th>
        <th>Buy</th>
        <th>Sell</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="rate in exchangeRates" :key="rate.name">
        <td>
          <img :src="rate.flag" :alt="rate.name + ' flag'" class="flag" />
        </td>
        <td>{{ rate.name }}</td>
        <td>{{ rate.buy.toFixed(2) }}</td>
        <td>{{ rate.sell.toFixed(2) }}</td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<style scoped>

</style>
