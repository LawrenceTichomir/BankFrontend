<script lang="ts">
import { defineComponent } from "vue";
import "@/assets/styles/side.css"
export default defineComponent({
  name: "Sidebar",
});
</script>

<template>
  <div class="sidebar">
    <nav>
      <ul>
        <li><RouterLink to="/">Home</RouterLink></li>
        <li><RouterLink to="/help">Help</RouterLink></li>
        <li><RouterLink to="/settings">Settings</RouterLink></li>
        <li><RouterLink to="/profile">Profile</RouterLink></li>
        <li><RouterLink to="/wallet">Wallet</RouterLink></li>
      </ul>
    </nav>
  </div>
</template>

<style scoped>

</style>
