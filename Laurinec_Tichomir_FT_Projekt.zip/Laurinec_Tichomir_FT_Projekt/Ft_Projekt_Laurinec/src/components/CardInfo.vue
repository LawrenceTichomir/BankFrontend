<script lang="ts">
import { defineComponent } from "vue";
import "@/assets/styles/cardinf.css"
export default defineComponent({
  name: "CardInfo",
  data() {
    return {
      cardInfo: {
        userId: "012 395 8647",
        type: "Personal",
        created: "October 20, 2020",
        validDate: "October 19, 2026",
      },
    };
  },
});
</script>

<template>
  <div class="card-info">
    <h3 class="title">Card Information</h3>
    <ul class="info-list">
      <li>
        <strong>User ID:</strong>
        <span>{{ cardInfo.userId }}</span>
      </li>
      <li>
        <strong>Type:</strong>
        <span>{{ cardInfo.type }}</span>
      </li>
      <li>
        <strong>Created:</strong>
        <span>{{ cardInfo.created }}</span>
      </li>
      <li>
        <strong>Valid Date:</strong>
        <span>{{ cardInfo.validDate }}</span>
      </li>
    </ul>
  </div>
</template>

<style scoped>

</style>
