<script lang="ts">
import { defineComponent } from "vue";
import "@/assets/styles/cardinf2.css"
export default defineComponent({
  name: "InfoCard",
  data() {
    return {
      profile: {
        picture: "/images/profile.jpg", // Path to the profile picture
        name: "Tichomír Laurinec",
        email: "tichomir.laurinec@student.ukf.sk",
        phone: "46-771-793-336",
      },
    };
  },
});
</script>

<template>
  <div class="profile-card">
    <img :src="profile.picture" alt="Profile Picture" class="profile-picture" />
    <div class="profile-details">
      <p>
        <strong>Name:</strong> <span>{{ profile.name }}</span>
      </p>
      <p>
        <strong>Email:</strong> <span>{{ profile.email }}</span>
      </p>
      <p>
        <strong>Phone:</strong> <span>{{ profile.phone }}</span>
      </p>
    </div>
  </div>
</template>

<style scoped>

</style>
