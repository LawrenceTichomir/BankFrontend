<script lang="ts">
import { defineComponent } from "vue";
import "@/assets/styles/apanel.css"
export default defineComponent({
  name: "ActionPanel",
  data() {
    return {
      actions: [
        { label: "Top up", icon: "/images/icons/top-up.png" },
        { label: "Scan & Pay", icon: "/images/icons/scan-and-pay.png" },
        { label: "Send", icon: "/images/icons/send.png" },
        { label: "Request", icon: "/images/icons/request.png" },
      ],
    };
  },methods: {
    goToProfile() {
      this.$router.push({ name: "profile" });
    },
  },
});
</script>

<template>
  <div class="action-panel">
    <button v-for="action in actions" :key="action.label" class="action-button" @click="goToProfile">
      <span class="icon-wrapper">
        <img :src="action.icon" :alt="action.label + ' icon'" />
      </span>
      <span class="label">{{ action.label }}</span>
    </button>
  </div>
</template>

<style scoped>

</style>
