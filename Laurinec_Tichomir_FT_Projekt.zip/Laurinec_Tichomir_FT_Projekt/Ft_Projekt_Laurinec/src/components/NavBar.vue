<script lang="ts">
import { defineComponent } from "vue";
import "@/assets/styles/navigation.css"
export default defineComponent({
  name: "NavigationBar",
});
</script>

<template>
  <header class="navbar">
    <div class="navbar-content">
      <div class="navbar-left">Lawrence Bank</div>
      <div class="navbar-center">
        <input type="text" placeholder="Search..." />
      </div>
    </div>
  </header>
</template>

<style scoped>

</style>
