<script lang="ts">
import { defineComponent } from "vue";
import "@/assets/styles/transaction.css"
export default defineComponent({
  name: "TransactionsSmall",
  data() {
    return {
      transactions: [
        {
          id: 1,
          name: "Daniel Jones",
          type: "C2C Transfer",
          date: "05/12/2023",
          amount: -250,
          avatar: "/images/1.jpg",
        },
        {
          id: 2,
          name: "Public Bank",
          type: "Mobile Reload",
          date: "22/08/2023",
          amount: 280,
          avatar: "/images/2.jpg",
        },
        {
          id: 3,
          name: "Store",
          type: "Payment Received",
          date: "22/08/2023",
          amount: 120,
          avatar: "/images/3.jpg",
        },
      ],
    };
  },
  methods: {
    goToWallet() {
      this.$router.push({ name: "wallet" });
    },
  },
});
</script>

<template>
  <div class="recent-transactions">
    <h3 class="title">Recent Transactions</h3>
    <ul class="transaction-list">
      <li v-for="transaction in transactions" :key="transaction.id" class="transaction-item">
        <img :src="transaction.avatar" :alt="transaction.name + ' avatar'" class="avatar"/>

        <div class="transaction-info">
          <p class="transaction-name">{{ transaction.name }}</p>
          <p class="transaction-type">{{ transaction.type }}</p>
        </div>

        <div class="transaction-details">
          <p class="transaction-date">{{ transaction.date }}</p>
          <p class="transaction-amount" :class="{ positive: transaction.amount > 0, negative: transaction.amount < 0 }">
            {{ transaction.amount > 0 ? '+' : '-' }} {{ Math.abs(transaction.amount) }} €
          </p>
        </div>

      </li>
    </ul>
    <button class="view-all-button" @click="goToWallet">
      View all transactions
    </button>
  </div>
</template>

<style scoped>

</style>
