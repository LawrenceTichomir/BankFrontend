<script lang="ts">
import { defineComponent } from "vue";
import { useBalanceStore } from "@/stores/balance";
import "@/assets/styles/cardcomp.css"
export default defineComponent({
  name: "CardComponent",
  data() {
    return {
      balanceStore: useBalanceStore()
    };
  },
});
</script>

<template>
  <div class="card">
    <div class="card-header">
      <h2>Your Balance</h2>
      <p class="balance">€{{ balanceStore.balance.toFixed(2) }}</p>
    </div>
    <div class="card-body">
      <p class="card-number">**** **** **** 5327</p>
      <div class="card-details">
        <p><strong>Valid Date:</strong> 10/26 </p>
        <p><strong>Card Holder:</strong>Tichomír Laurinec</p>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>
